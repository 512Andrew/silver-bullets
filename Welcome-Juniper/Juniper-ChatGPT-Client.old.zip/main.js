const { app, BrowserWindow } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 800,
    height: 600,
    show: false, // Don't show until ready
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: true,
      contextIsolation: false,
    }
  });

  win.once('ready-to-show', () => {
    win.show();
  });

  win.loadFile('index.html');
ipcMain.on('terminal-typed', (event, data) => {
  ptyProcess.write(data);
});

ptyProcess.on('data', (data) => {
  mainWindow.webContents.send('terminal-incData', data);
});

}

app.whenReady().then(() => {
    createWindow();
    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
});
