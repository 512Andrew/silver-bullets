const { Terminal } = require('xterm');
const { FitAddon } = require('xterm-addon-fit');
const pty = require('node-pty');
const os = require('os');

// Pick your shell
const shell = os.platform() === 'win32' ? 'powershell.exe' : 'bash';

const term = new Terminal({
  cursorBlink: true,
  fontFamily: 'monospace',
  fontSize: 14,
  theme: {
    background: '#1e1e1e',
    foreground: '#00ffcc'
  }
  
  
});
const term = new Terminal();
term.open(document.getElementById('terminal'));

ipcRenderer.on('terminal-incData', (event, data) => {
  term.write(data);
});

term.onData(e => {
  ipcRenderer.send('terminal-typed', e);
});

const fitAddon = new FitAddon();
term.loadAddon(fitAddon);
term.open(document.getElementById('terminal'));
fitAddon.fit();

const ptyProcess = pty.spawn(shell, [], {
  name: 'xterm-color',
  cols: 80,
  rows: 30,
  cwd: process.env.HOME,
  env: process.env
});

ptyProcess.onData(data => term.write(data));
term.onData(data => ptyProcess.write(data));
